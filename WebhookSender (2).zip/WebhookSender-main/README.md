# WebhookSender
C# Discord Webhook Sender (very simple) <br>

# Setup
Visual Studio 2019 <br>
.NetFramework <br>
`$ git clone https://github.com/seungyup26/webhooksender`
